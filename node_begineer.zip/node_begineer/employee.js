// var name = "Tahmida Lima";
// var myFunction = function(){
// 	console.log('hello...');
// };
// module.exports.name = name; 
// module.exports.myFunction = myFunction; 
module.exports = {
	name:"Tahmida Lima!!!!",
	myFunction:function(){
		console.log('helllllo......');
	}
}